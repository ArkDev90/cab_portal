<?php
class controller extends wc_controller {

	public function __construct() {
		parent::__construct();
		$this->ui					= new ui();
		$this->input				= new input();
		$this->report_summary_model	= new report_summary_model();
		$this->session				= new session();
	}

	public function listing() {
		$this->view->load('report_summary/report_summary');
	}

	public function form_51_a() {
		$data['ui'] = $this->ui;
		$data['show_input'] = true;
		$this->view->load('report_summary/form_51_a', $data);
	}

	public function form_51_b() {
		$data['ui'] = $this->ui;
		$data['show_input'] = true;
		$this->view->load('report_summary/form_51_b', $data);
	}
	
	public function form_51b_pdf() {
		$report_type = $_GET['report_type'];
		$quarter = $_GET['quarter'];
		$quarter = str_replace('+', ' ', $quarter);
		$start_date = $_GET['start_date'];
		$start_date = str_replace('+', ' ', $start_date);
		$end_date = $_GET['end_date'];
		$end_date = str_replace('+', ' ', $end_date);
		$year = $_GET['year'];
		$start_year = $_GET['start_year'];
		$end_year = $_GET['end_year'];
		if (!empty($_GET["category"])) {
			$category = $_GET['category'];
			$category = str_replace('+', ' ', $category);
		}
		else {
			$category = '';
		}
		$pdf = new fpdf('L', 'mm', 'Legal');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(335,7,'INTERNATIONAL CARGO TRAFFIC FLOW', 0, 1, 'C');
		$pdf->Cell(335,7,'(in Kilograms)', 0, 1, 'C');

		if (!empty($_GET["summary_route"])) {
			$summary_route = $_GET['summary_route'];
			$summary_route = str_replace('+', ' ', $summary_route);
		}
		else {
			$summary_route = '';
		}
		if (!empty($_GET["a_rank_alpha"])) {
			$a_rank_alpha = $_GET['a_rank_alpha'];
			$a_rank_alpha = str_replace('+', ' ', $a_rank_alpha);
		}
		else {
			$a_rank_alpha = '';
		}
		if (!empty($_GET["a_market_share"])) {
			$a_market_share = $_GET['a_market_share'];
			$a_market_share = str_replace('+', ' ', $a_market_share);
		}
		else {
			$a_market_share = '';
		}
		if (!empty($_GET["c_rank_alpha"])) {
			$c_rank_alpha = $_GET['c_rank_alpha'];
			$c_rank_alpha = str_replace('+', ' ', $c_rank_alpha);
		}
		else {
			$c_rank_alpha = '';
		}
		if (!empty($_GET["h_market_share"])) {
			$h_market_share = $_GET['h_market_share'];
			$h_market_share = str_replace('+', ' ', $h_market_share);
		}
		else {
			$h_market_share = '';
		}

		$get51bAC = $this->report_summary_model->get51BAC($report_type, $quarter, $year, $category, $a_rank_alpha, $c_rank_alpha, $start_date, $end_date);
			
		if ($category == 'by Airline') {
			if ($summary_route == 'Summary') {
				if ($report_type == 'Quarterly') {
					$pdf->Cell(335,7, $quarter.' CY '.$year.' Summary', 0, 1, 'C');
				}
				else if ($report_type == 'Consolidated') {
					$pdf->Cell(335,7, $start_date.' - '.$end_date.' CY '.$year, 0, 1, 'C');
				}
				else {
					$pdf->Cell(335,7, 'CY '.$year, 0, 1, 'C');
				}

				$pdf->Cell(335,7, '', 0, 1, 'C');
				$pdf->SetFont('Arial','B',9);
				$pdf->Cell(30,7, '', 1, 0, 'C');
				$pdf->Cell(55,7, 'AIRLINE', 1, 0, 'C'); 
				$pdf->Cell(55,7, 'POINTS SERVED', 1, 0, 'C');
				$pdf->Cell(55,7, 'Incoming (Kilograms)', 1, 0, 'C');
				$pdf->Cell(55,7, 'Outgoing (Kilograms)', 1, 0, 'C');
				if ($a_market_share == 'Market Share') {
					$pdf->Cell(55,7, 'TOTAL (Kilograms)', 1, 0, 'C');
					$pdf->Cell(30,7, 'MS', 1, 1, 'C');
				}
				else {
					$pdf->Cell(55,7, 'TOTAL (Kilograms)', 1, 1, 'C');
				}
				$pdf->SetFont('Arial','',9);
				if (empty($get51bAC->result)) {
					if ($a_market_share == 'Market Share') {
						$pdf->Cell(335,7,"No Record",1,1, 'C');
					}
					else {
						$pdf->Cell(305,7,"No Record",1,1, 'C');
					}
				}
				$count = 1;
				$totalcargoRev = 0;
				$totalcargoRevDep = 0;
				$grandtotal = 0;
				$totalms = 0;
				foreach ($get51bAC->result as $key => $row) {
					$pdf->Cell(30,7, $count++, 1,0, 'C');
					$pdf->Cell(55,7, $row->aircraft, 1,0, 'L');
					$pdf->Cell(55,7, $row->routeTo.'/'.$row->routeFrom, 1,0, 'L');
					$pdf->Cell(55,7, number_format($row->cargoRev, 2), 1,0, 'R');
					$pdf->Cell(55,7, number_format($row->cargoRevDep, 2), 1,0, 'R');
					if ($a_market_share == 'Market Share') {
						$pdf->Cell(55,7, number_format($row->total, 2), 1,0, 'R');
						$pdf->Cell(30,7, 'MS', 1,1, 'R');
					}
					else {
						$pdf->Cell(55,7, $row->total, 1,1, 'R');
					}
					$totalcargoRev += $row->cargoRev;
					$totalcargoRevDep += $row->cargoRevDep;
					$grandtotal += $row->total;
					//$totalms += 0;
				}
				$pdf->setFont('Arial','B',9);
				$pdf->Cell(140,7, 'GRAND TOTAL', 1, 0, 'R');
				$pdf->Cell(55,7, number_format($totalcargoRev, 2), 1, 0, 'R');
				$pdf->Cell(55,7, number_format($totalcargoRevDep, 2), 1, 0, 'R');
				$pdf->Cell(55,7, number_format($grandtotal, 2), 1, 0, 'R');
				if ($a_market_share == 'Market Share') {
					$pdf->Cell(30,7, 'MS', 1, 1, 'R');
				}
			}

			else {
				if ($report_type == 'Quarterly') {
					$pdf->Cell(335,7, $quarter.' CY '.$year.' Per Route', 0, 1, 'C');
				}
				else if ($report_type == 'Consolidated') {
					$pdf->Cell(335,7, $start_date.' - '.$end_date.' CY '.$year, 0, 1, 'C');
				}
				else {
					$pdf->Cell(335,7, 'CY '.$year, 0, 1, 'C');
				}

				$pdf->Cell(335,7, '', 0, 1, 'C');
				$pdf->SetFont('Arial','B',9);
				$pdf->Cell(30,7, '', 1, 0, 'C');
				$pdf->Cell(45,7, 'AIRLINE', 1, 0, 'C'); 
				$pdf->Cell(45,7, 'COUNTRY', 1, 0, 'C');
				$pdf->Cell(45,7, 'ROUTE', 1, 0, 'C');
				$pdf->Cell(45,7, 'Incoming (Kilograms)', 1, 0, 'C');
				$pdf->Cell(45,7, 'Outgoing (Kilograms)', 1, 0, 'C');
				if ($a_market_share == 'Market Share') {
					$pdf->Cell(45,7, 'TOTAL (Kilograms)', 1, 0, 'C');
					$pdf->Cell(30,7, 'MS', 1, 1, 'C');
				}
				else {
					$pdf->Cell(45,7, 'TOTAL (Kilograms)', 1, 1, 'C');
				}
				$pdf->SetFont('Arial','',9);
				if (empty($get51bAC->result)) {
					if ($a_market_share == 'Market Share') {
					$pdf->Cell(330,7,"No Record",1,1, 'C');
					}
					else {
						$pdf->Cell(300,7,"No Record",1,1, 'C');
					}
				}
				$count = 1;
				$totalcargoRev = 0;
				$totalcargoRevDep = 0;
				$grandtotal = 0;
				$totalms = 0;
				foreach ($get51bAC->result as $key => $row) {
					$pdf->Cell(30,7, $count++, 1,0, 'C');
					$pdf->Cell(45,7, $row->aircraft, 1,0, 'L');
					$pdf->Cell(45,7, $row->title, 1,0, 'L');
					$pdf->Cell(45,7, $row->routeTo.'/'.$row->routeFrom, 1,0, 'L');
					$pdf->Cell(45,7, number_format($row->cargoRev, 2), 1,0, 'R');
					$pdf->Cell(45,7, number_format($row->cargoRevDep, 2), 1,0, 'R');
					if ($a_market_share == 'Market Share') {
						$pdf->Cell(45,7, number_format($row->total, 2), 1,0, 'R');
						$pdf->Cell(30,7, 'MS', 1,1, 'R');
					}
					else {
						$pdf->Cell(45,7, $row->total, 1,1, 'R');
					}
					$totalcargoRev += $row->cargoRev;
					$totalcargoRevDep += $row->cargoRevDep;
					$grandtotal += $row->total;
					//$totalms += 0;
				}
				$pdf->setFont('Arial','B',9);
				$pdf->Cell(165,7, 'GRAND TOTAL', 1, 0, 'R');
				$pdf->Cell(45,7, number_format($totalcargoRev, 2), 1, 0, 'R');
				$pdf->Cell(45,7, number_format($totalcargoRevDep, 2), 1, 0, 'R');
				$pdf->Cell(45,7, number_format($grandtotal, 2), 1, 0, 'R');
				if ($a_market_share == 'Market Share') {
					$pdf->Cell(30,7, 'MS', 1, 1, 'R');
				}
			}
		}
		else if ($category == 'by Country') {
			if ($report_type == 'Quarterly') {
				$pdf->Cell(335,7, $quarter.' CY '.$year.' Summary', 0, 1, 'C');
			}
			else if ($report_type == 'Consolidated') {
				$pdf->Cell(335,7, $start_date.' - '.$end_date.' CY '.$year, 0, 1, 'C');
			}
			else {
				$pdf->Cell(335,7, 'CY '.$year, 0, 1, 'C');
			}

			$pdf->Cell(335,7, '', 0, 1, 'C');
			$pdf->SetFont('Arial','B',9);
			$pdf->Cell(110,7, 'COUNTRY', 1, 0, 'C'); 
			$pdf->Cell(110,7, 'AIRLINE/ROUTE', 1, 0, 'C');
			$pdf->Cell(110,7, 'TOTAL', 1, 1, 'C');

			$pdf->SetFont('Arial','',9);
			if (empty($get51bAC->result)) {
				$pdf->Cell(330,7,"No Record",1,1, 'C');
			}
			$count = 1;
			$grandtotal = 0;
			foreach ($get51bAC->result as $key => $row) {
				$pdf->Cell(110,7, $row->title, 1,0, 'L');
				$pdf->Cell(110,7, $row->aircraft.' '.$row->routeTo.'/'.$row->routeFrom, 1,0, 'L');
				$pdf->Cell(110,7, number_format($row->total, 2), 1,1, 'R');
				$grandtotal += $row->total;
			}
			$pdf->setFont('Arial','B',9);
			$pdf->Cell(220,7, 'GRAND TOTAL', 1, 0, 'R');
			$pdf->Cell(110,7, number_format($grandtotal, 2), 1, 0, 'R');
		}

		else if ($category == 'Historical') {
			$get51bH = $this->report_summary_model->get51BH($start_year, $end_year);
			$pdf->Cell(335,7, 'CY '.$start_year.' - '.$end_year, 0, 1, 'C');

			$pdf->Cell(335,7, '', 0, 1, 'C');
			$pdf->SetFont('Arial','B',9);
			$pdf->Cell(50,7, 'AIRLINE', 1, 0, 'C'); 
			for ($a = $start_year; $a <= $end_year; $a++) { 
				$pdf->Cell(30,7, $a, 1, 0, 'C'); 
			}
			if ($h_market_share == 'Market Share') {
				$pdf->Cell(30,7, 'MS', 1, 0, 'C');
			}
			$pdf->Cell(1,7, '', 0, 1, 'C'); 
			$pdf->SetFont('Arial','',9);
			if (empty($get51bH->result)) {
				$pdf->Cell(50,7,"No Record",0,1, 'L');
			}
			foreach ($get51bH->result as $key => $row) {
				$pdf->Cell(50,7, $row->aircraft, 1,0, 'L');
				for ($a = $start_year; $a <= $end_year; $a++) { 
					$pdf->Cell(30,7, $row->total, 1, 0, 'R');
				}
				$pdf->Cell(1,7, '', 0,1, 'L');
			}
		}

		$pdf->Output();
	}

	public function form_61_a() {
		$data['ui'] = $this->ui;
		$data['show_input'] = true;
		$this->view->load('report_summary/form_61_a', $data);
	}

	public function form_61_b() {
		$data['airlines'] = $this->report_summary_model->getAirlines();
		$data['ui'] = $this->ui;
		$data['show_input'] = true;
		$this->view->load('report_summary/form_61_b', $data);
	}

	public function form_61b_pdf() {
		$report_type = $_GET['report_type'];
		$quarter = $_GET['quarter'];
		$quarter = str_replace('+', ' ', $quarter);
		$start_date = $_GET['start_date'];
		$start_date = str_replace('+', ' ', $start_date);
		$end_date = $_GET['end_date'];
		$end_date = str_replace('+', ' ', $end_date);
		$year = $_GET['year'];
		if (!empty($_GET["category"])) {
			$category = $_GET['category'];
			$category = str_replace('+', ' ', $category);
		}
		else {
			$category = '';
		}
		if (!empty($_GET["passenger_cargo"])) {
			$passenger_cargo = $_GET['passenger_cargo'];
			$passenger_cargo = str_replace('+', ' ', $passenger_cargo);
		}
		else {
			$passenger_cargo = '';
		}
		if (!empty($_GET["rank_alpha"])) {
			$rank_alpha = $_GET['rank_alpha'];
			$rank_alpha = str_replace('+', ' ', $rank_alpha);
		}
		else {
			$rank_alpha = '';
		}
		if (!empty($_GET["airline"])) {
			$airline = $_GET['airline'];
			$airline = str_replace('+', ' ', $airline);
		}
		else {
			$airline = '';
		}

		$pdf = new fpdf('L', 'mm', 'Legal');
		$pdf->AddPage();
		$pdf->SetFont('Arial','',12);
		$pdf->Cell(335,7,'NON-SCHEDULED DOMESTIC (CHARTERER)', 0, 1, 'C');
		$pdf->Cell(335,7,'AIR TRANSPORTATION SERVICES', 0, 1, 'C');
		$pdf->Cell(335,7,'TRAFFIC AND OPERATING STATISTICS', 0, 1, 'C');
		if ($report_type == 'Quarterly') {
			$pdf->Cell(335,7, $quarter.' CY '.$year, 0, 1, 'C');
		}
		else if ($report_type == 'Consolidated') {
			$pdf->Cell(335,7, $start_date.' - '.$end_date.' CY '.$year, 0, 1, 'C');
		}
		else {
			$pdf->Cell(335,7, 'CY '.$year, 0, 1, 'C');
		}

		$get61bSummary = $this->report_summary_model->get61BSummary($report_type, $quarter, $year, $start_date, $end_date, $rank_alpha, $passenger_cargo);
		if ($category == 'Summary Report') {
			$pdf->Cell(335,7, '', 0, 1, 'C');
			$pdf->SetFont('Arial','B',9);
			$pdf->Cell(150,7, 'AIR TAXI OPERATORS', 1, 0, 'C'); 
			$pdf->Cell(90,7, 'PASSENGERS CARRIED', 1, 0, 'C');
			$pdf->Cell(90,7, 'CARGO CARRIED (Kilograms)', 1, 1, 'C');

			$pdf->SetFont('Arial','',9);
			if (empty($get61bSummary->result)) {
				$pdf->Cell(330,7,"No Record",1,1, 'C');
			}
			$count = 1;
			$totalpassengers_num = 0;
			$totalcargo_qty = 0;
			foreach ($get61bSummary->result as $key => $row) {
				$pdf->Cell(20,7, $count++, 1,0, 'C');
				$pdf->Cell(130,7, $row->name, 1,0, 'L');
				$pdf->Cell(90,7, $row->passengers_num, 1,0, 'R');
				$pdf->Cell(90,7, number_format($row->cargo_qty, 2), 1,1, 'R');

				$totalpassengers_num += $row->passengers_num;
				$totalcargo_qty += $row->cargo_qty;
			}
			$pdf->setFont('Arial','B',9);
			$pdf->Cell(150,7, 'GRAND TOTAL', 1, 0, 'C');
			$pdf->Cell(90,7, $totalpassengers_num, 1, 0, 'R');
			$pdf->Cell(90,7, number_format($totalcargo_qty, 2), 1, 0, 'R');
		}

		else if ($category == 'Detailed Summary Report') {
			$pdf->Cell(335,7, '', 0, 1, 'C');
			$pdf->SetFont('Arial','B',9);
			$pdf->Cell(100,10, 'Air Taxi Operators', 1, 0, 'C'); 
			$pdf->Cell(50,10, 'Locations', 1, 0, 'C');
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(35,5, 'Distance', 'TLR',0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(35,5, 'Travelled (km)', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 35);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(40,5, 'Flying Time', 1,0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(20,5, 'Hours', 'BLR',0, 'C');
			$pdf->Cell(20,5, 'Minutes', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 40);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(35,5, 'Passengers', 'TLR',0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(35,5, 'Carried', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 35);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(35,5, 'Cargo Carried', 'TLR',0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(35,5, '(Kilograms)', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 35);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(35,5, 'Revenue Derived', 'TLR',0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(35,5, '(Php)', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 35);
			$pdf->Cell(1,10, '', 0,1, 'C');

			$pdf->SetFont('Arial','',9);
			if (empty($get61bSummary->result)) {
				$pdf->Cell(330,7,"No Record",1,1, 'C');
			}
			$count = 1;
			$totalpassengers_num = 0;
			$totalcargo_qty = 0;
			$totaldistance = 0;
			$totalhours = 0;
			$totalminutes = 0;
			$totalrevenue = 0;
			foreach ($get61bSummary->result as $key => $row) {
				$pdf->Cell(20,7, $count++, 1,0, 'C');
				$pdf->Cell(80,7, $row->name, 1,0, 'L');
				$pdf->Cell(50,7, $row->origin.'/'.$row->destination, 1,0, 'L');
				$pdf->Cell(35,7, $row->distance, 1, 0, 'R');
				$pdf->Cell(20,7, $row->hours, 1, 0, 'R');
				$pdf->Cell(20,7, $row->minutes, 1, 0, 'R');
				$pdf->Cell(35,7, $row->passengers_num, 1, 0, 'R');
				$pdf->Cell(35,7, $row->cargo_qty, 1, 0, 'R');
				$pdf->Cell(35,7, $row->revenue, 1, 1, 'R');

				$totalpassengers_num += $row->passengers_num;
				$totalcargo_qty += $row->cargo_qty;
				$totaldistance += $row->distance;
				$totalhours += $row->hours;
				$totalminutes += $row->minutes;
				$totalrevenue += $row->revenue;
			}
			$pdf->setFont('Arial','B',9);
			$pdf->Cell(150,7, 'GRAND TOTAL', 1, 0, 'C');
			$pdf->Cell(35,7, $totaldistance, 1, 0, 'R');
			$pdf->Cell(20,7, $totalhours, 1, 0, 'R');
			$pdf->Cell(20,7, $totalminutes, 1, 0, 'R');
			$pdf->Cell(35,7, $totalpassengers_num, 1, 0, 'R');
			$pdf->Cell(35,7, $totalcargo_qty, 1, 0, 'R');
			$pdf->Cell(35,7, $totalrevenue, 1, 1, 'R');
		}

		else {
			$get61bSummaryPerOperator = $this->report_summary_model->get61BSummaryPerOperator($report_type, $quarter, $year, $start_date, $end_date, $airline);
			$pdf->Cell(335,7, '', 0, 1, 'C');
			$pdf->SetFont('Arial','B',9);
			$pdf->Cell(20,10, '', 1, 0, 'C'); 
			$pdf->Cell(30,10, 'Aircraft Type', 1, 0, 'C'); 
			$pdf->Cell(30,10, 'Aircraft Number', 1, 0, 'C'); 
			$pdf->Cell(35,10, 'Origin', 1, 0, 'C');
			$pdf->Cell(35,10, 'Location', 1, 0, 'C');
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(35,5, 'Distance', 'TLR',0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(35,5, 'Travelled (km)', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 35);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(40,5, 'Flying Time', 1,0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(20,5, 'Hours', 'BLR',0, 'C');
			$pdf->Cell(20,5, 'Minutes', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 40);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(35,5, 'Passengers', 'TLR',0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(35,5, 'Carried', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 35);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(35,5, 'Cargo Carried', 'TLR',0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(35,5, '(Kilograms)', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 35);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			$pdf->Cell(35,5, 'Revenue Derived', 'TLR',0, 'C');
			$pdf->SetY($y + 5);
			$pdf->SetX($x);
			$pdf->Cell(35,5, '(Php)', 'BLR',0, 'C');
			$pdf->SetY($y);
			$pdf->SetX($x + 35);
			$pdf->Cell(1,10, '', 0,1, 'C');

			$pdf->SetFont('Arial','',9);
			if (empty($get61bSummaryPerOperator->result)) {
				$pdf->Cell(330,7,"No Record",1,1, 'C');
			}
			$count = 1;
			$totalpassengers_num = 0;
			$totalcargo_qty = 0;
			$totaldistance = 0;
			$totalhours = 0;
			$totalminutes = 0;
			$totalrevenue = 0;
			foreach ($get61bSummaryPerOperator->result as $key => $row) {
				$pdf->Cell(20,7, $count++, 1,0, 'C');
				$pdf->Cell(30,7, $row->title, 1,0, 'L');
				$pdf->Cell(30,7, $row->aircraft_num, 1,0, 'L');
				$pdf->Cell(35,7, $row->origin, 1,0, 'L');
				$pdf->Cell(35,7, $row->destination, 1,0, 'L');
				$pdf->Cell(35,7, $row->distance, 1, 0, 'R');
				$pdf->Cell(20,7, $row->flown_hour, 1, 0, 'R');
				$pdf->Cell(20,7, $row->flown_min, 1, 0, 'R');
				$pdf->Cell(35,7, $row->passengers_num, 1, 0, 'R');
				$pdf->Cell(35,7, $row->cargo_qty, 1, 0, 'R');
				$pdf->Cell(35,7, $row->revenue, 1, 1, 'R');

				$totalpassengers_num += $row->passengers_num;
				$totalcargo_qty += $row->cargo_qty;
				$totaldistance += $row->distance;
				$totalhours += $row->flown_hour;
				$totalminutes += $row->flown_min;
				$totalrevenue += $row->revenue;
			}
			$pdf->setFont('Arial','B',9);
			$pdf->Cell(150,7, 'GRAND TOTAL', 1, 0, 'C');
			$pdf->Cell(35,7, $totaldistance, 1, 0, 'R');
			$pdf->Cell(20,7, $totalhours, 1, 0, 'R');
			$pdf->Cell(20,7, $totalminutes, 1, 0, 'R');
			$pdf->Cell(35,7, $totalpassengers_num, 1, 0, 'R');
			$pdf->Cell(35,7, $totalcargo_qty, 1, 0, 'R');
			$pdf->Cell(35,7, $totalrevenue, 1, 1, 'R');
		}

		$pdf->Output();
	}

	public function ajax($task) {
		$ajax = $this->{$task}();
		if ($ajax) {
			header('Content-type: application/json');
			echo json_encode($ajax);
		}
	}
}