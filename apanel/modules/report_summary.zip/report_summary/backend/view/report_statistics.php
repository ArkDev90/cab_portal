<style>
	li {
		display:block;
	}
</style>
<div class="panel panel-primary br-xs">
	<div class="panel-heading bb-colored text-center">
		LIST OF STATISTICS REPORTS
	</div>
	<div>
		<ul style = "list-style-type:none; padding: 2px">
			<li><a><b>Form 51-A</b> : Statistic Report</a>
			<li><a><b>Form 51-B</b> : Statistic Report</a>
			<li><a><b>Form 61-A</b> : Statistic Report</a>
			<li><a><b>Form 61-B</b> : Statistic Report</a>
			<li><a><b>Form 71-A</b> : Statistic Report</a>
			<li><a><b>Form 71-B</b> : Statistic Report</a>
			<li><a><b>Form 71-C</b> : Statistic Report</a>
			<li><a><b>ER2 FORM2</b> : Statistic Report</a>
			<li><a><b>Form T1A</b> : Statistic Report</a>
		</ul>
	</div>
</div>