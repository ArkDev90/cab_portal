<form action="" method="post">
<div class="panel panel-primary br-xs">
	<div class="panel-heading bb-colored text-center">
		FORM 51-A : Traffic Flow - Quarterly Report on Scheduled International Services
	</div>
	<div class="panel panel-primary br-xs" style = "margin: 2%; padding: 2%">
        <div class = "row">
            <div class = "col-md-2" style = "text-align:right">
                Report Type:
            </div>
            <div class = "col-md-3" >
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('report_type')
                    ->setId('report_type')
                    ->setList(array('Per Airline' => 'Per Airline','Per Route/Sector' => 'Per Route/Sector', 'Per Country' => 'Per Country', 'Historical' => 'Historical', 'CoTerm & 5th Freedom' => 'CoTerm & 5th Freedom'))
                    ->setId('report_type')
                    ->draw($show_input);
                ?>
            </div>
            <div class = "col-md-3" id = "div_timeline">
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('timeline')
                    ->setList(array('Per Year','Per Quarter', 'Per Semester', 'Consolidated'))
                    ->setId('timeline')
                    ->draw($show_input);
                ?>
            </div>
            <div class = "col-md-3" id = "div_year">
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('year')
                    ->setId('year')
                    ->setList(array('2018','2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010'))
                    ->draw($show_input);
                ?>
            </div>
            <div id = "date_range">
                <div class = "col-md-3" style = "padding:0%">
                    <?php
                        echo $ui->formField('dropdown')
                        ->setLabel('From:')
                        ->setSplit('col-md-4', 'col-md-8')
                        ->setName('start_date')
                        ->setId('start_date')
                        ->setList(array('2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017'))
                        ->draw($show_input);
                    ?>
                </div>
                <div class = "col-md-3" style = "padding:0%">
                    <?php
                        echo $ui->formField('dropdown')
                        ->setLabel('To:')
                        ->setSplit('col-md-4', 'col-md-8')
                        ->setName('end_date')
                        ->setId('end_date')
                        ->setList(array('2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017'))
                        ->draw($show_input);
                    ?>
                </div>
            </div>
        </div>
        <div class = "row">
            <div class = "col-md-3"><input type="radio" name="filterby" id="filterby" checked = "checked"> Alphabetical</div>
            <div class = "col-md-2"><input type="radio" name="filterby" id="filterby"> Ranking</div>
            <div class = "col-md-4"><input type="checkbox" name="filterbySub" id = "load_factor" value = "load_factor" checked = "checked"> Show Load Factor</div>
        </div>
        <div class = "row" style = "margin-top:1%">
            <div class = "col-md-3"></div>
            <div class = "col-md-2"></div>
            <div class = "col-md-4"><input type="checkbox" name="filterbySub" id = "market_share" value = "market_share"> Show Market Share</div>
        </div>
    </div>
    <div class = "row" style = "margin: 0% 0% 2% 2%">
        File Type: 
        <span style="margin-left:2px;">
            <a id="pdf" target="_blank" style="font-size: 8pt; font-weight: bold;  border: 3px solid; padding: 5px; text-decoration: none; color: #444; background: #EEE" href="/portal/srs_form51a/airline/per_year/2018/alphabetical/load_factor-market_share/">PDF</a>
        </span>
        <span style="margin-left:2px;">
            <a id="excel_" style="font-size: 8pt; font-weight: bold;  border: 3px solid; padding: 5px; text-decoration: none; color: #444; background: #EEE">CSV</a>
        </span>
    </div>
</div>
</form>
<script>
    $(document).ready(function(){
        $('#div_timeline').show();
        $('#div_year').show();
        $('#date_range').hide();
        $('#report_type').on('change', function() {
            var report_type = $('#report_type').val();
            if (report_type == 'Historical') {
                $('#div_timeline').hide();
                $('#div_year').hide();
                $('#date_range').show();
            }
            else {
                $('#div_timeline').show();
                $('#div_year').show();
                $('#date_range').hide();
            }
        });
    });
</script>