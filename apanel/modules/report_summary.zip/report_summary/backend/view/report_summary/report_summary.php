<style>
	li {
		display:block;
	}
</style>
<div class="panel panel-primary br-xs">
	<div class="panel-heading bb-colored text-center">
		LIST OF SUMMARY REPORTS
	</div>
	<div>
		<ul style = "list-style-type:none; padding: 2px">
			<li><a href = "<?php echo MODULE_URL ?>form_51_a"><b>Form 51-A</b> : Traffic Flow - Quarterly Report on Scheduled International Services</a><br>
			<li><a href = "<?php echo MODULE_URL ?>form_51_b"><b>Form 51-B</b> : Monthly International Cargo Traffic Flow</a><br>
			<li><a href = "<?php echo MODULE_URL ?>form_61_a"><b>Form 61-A</b> : Monthly Statement of Traffic and Operating Statistics (Agricultural Aviation)</a><br>
			<li><a href = "<?php echo MODULE_URL ?>form_61_b"><b>Form 61-B</b> : Monthly Statement of Traffic and Operating Statistics</a><br>
			<li><a><b>Form 71-A</b> : International Airfreight Forwarder Cargo Production Report</a><br>
			<li><a><b>Form 71-B</b> : Domestic Airfreight Forwarder Cargo Production Report</a><br>
			<li><a><b>Form 71-C</b> : Cargo Sales Agency Report</a><br>
			<li><a><b>Form T1-A</b> : Domestic Sector Load Report</a><br>
			<li><a><b>CAB Form</b> : Summary of Hawbs</a><br>
		</ul>
	</div>
</div>