<style>
	
</style>
<div class="panel panel-primary br-xs">
	<div class="panel-heading bb-colored text-center">
		FORM 61-A : Monthly Statement of Traffic and Operating Statistics (Agricultural Aviation)
	</div>
	<div class="panel panel-primary br-xs" style = "margin: 2%; padding: 2%">
        <div class = "row">
            <div class = "col-md-2" style = "text-align:right">
                Report Type:
            </div>
            <div class = "col-md-3" >
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('report_type')
                    ->setList(array('Quarterly','Consolidated', 'Yearly'))
                    ->setId('report_type')
                    ->draw($show_input);
                ?>
            </div>
            <div class = "col-md-3" >
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('timeline')
                    ->setList(array('1st Quarter(Jan,Feb,Mar)','2nd Quarter(Apr,May,Jun)','3rd Quarter(July,Aug,Sep)','4th Quarter(Oct,Nov,Dec)',))
                    ->setId('timeline')
                    ->draw($show_input);
                ?>
            </div>
            <div class = "col-md-3">
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('year')
                    ->setId('year')
                    ->setList(array('2018','2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010'))
                    ->draw($show_input);
                ?>
            </div>
        </div><br>
        <div class = "row">
        <div class = "col-md-12">
        <div class = "col-md-4"><input type="radio" name="report"> Summary Report</div>
        <div class = "col-md-4"><input type="radio" name="report"> Detailed Summary Report</div>
        <div class = "col-md-4"><input type="radio" name="report"> Summary per Operator</div>
        </div>
        </div>

        <div class = "row">
        <div class = "col-md-12">
        <div class = "col-md-8">
            <div class = "col-md-8">
                <div class = "col-md-8">
                        <input type="radio" name="filterby"> Alphabetical
                        </div><br><br>
                        <div class = "col-md-8">
                        <input type="radio" name="filterby"> Ranking
                        </div>
                </div>
        </div>
        <div class = "col-md-4"> 
        <?php
                    echo $ui->formField('dropdown')
                    ->setName('year')
                    ->setId('year')
                    ->setList(array('Airtrac Agricultural Corporation','Airwolf Aviation Corporation','Dana Farms Avations, Inc.'))
                    ->draw($show_input);
        ?>
        </div>
        </div>

     
    
</div>
</div>
&nbsp; 
File Type: <span style="margin-left:2px;">
				<a id="pdf" target="_blank" style="font-size: 8pt; font-weight: bold;  border: 3px solid; padding: 5px; text-decoration: none; color: #444; background: #EEE" href="/portal/srs_form51a/airline/per_year/2018/alphabetical/load_factor-market_share/">PDF</a>
			</span>

            <span style="margin-left:2px;">
            <a id="excel_" style="font-size: 8pt; font-weight: bold;  border: 3px solid; padding: 5px; text-decoration: none; color: #444; background: #EEE">CSV</a>
            </span><br><br>
</div>