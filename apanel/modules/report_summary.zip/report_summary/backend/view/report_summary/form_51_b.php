<form action="" method="post" id = "form51b">
<div class="panel panel-primary br-xs" id="filters">
	<div class="panel-heading bb-colored text-center">
		FORM 51-B : Monthly International Cargo Traffic Flow
	</div>
    <div class = "row">
	<div class="panel panel-primary br-xs col-md-8" style = "margin: 2% 0% 2% 3%; padding: 2%">
        <div class = "row">
            <div class = "col-md-1" style = "text-align:left; padding:0% 10% 0% 1%">
                Report Type:
            </div>
            <div class = "col-md-2" style = "padding:0% 1% 0% 0%">
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('report_type')
                    ->setId('report_type')
                    ->setList(array('Quarterly' => 'Quarterly','Consolidated' => 'Consolidated', 'Yearly' => 'Yearly'))
                    ->draw($show_input);
                ?>
            </div>
            <div class = "col-md-4" id = "div_quarter" style = "padding:0% 2% 0% 1%">
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('quarter')
                    ->setList(array('1st Quarter' => '1st Quarter (Jan, Feb, March)', '2nd Quarter' => '2nd Quarter (Apr, May, Jun)', '3rd Quarter' => '3rd Quarter (Jul, Aug, Sep)', '4th Quarter' => '4th Quarter (Oct, Nov, Dec)'))
                    ->setId('quarter')
                    ->draw($show_input);
                ?>
            </div>
            <div id = "date_range">
                <div class = "col-md-1" style = "text-align:left; padding:0% 2% 0% 1%">
                    From:
                </div>
                <div class = "col-md-2" style = "padding:0% 1% 0% 0%">
                    <?php
                        echo $ui->formField('dropdown')
                        ->setName('start_date')
                        ->setId('start_date')
                        ->setList(array('1st Quarter' => '1st Quarter', '2nd Quarter' => '2nd Quarter', '3rd Quarter' => '3rd Quarter', '4th Quarter' => '4th Quarter'))
                        ->draw($show_input);
                    ?>
                </div>
                <div class = "col-md-1" style = "text-align:left; padding:0% 2% 0% 1%">
                    To:
                </div>
                <div class = "col-md-2" style = "padding:0% 1% 0% 0%">
                    <?php
                        echo $ui->formField('dropdown')
                        ->setName('end_date')
                        ->setId('end_date')
                        ->setList(array('1st Quarter' => '1st Quarter', '2nd Quarter' => '2nd Quarter', '3rd Quarter' => '3rd Quarter', '4th Quarter' => '4th Quarter'))
                        ->draw($show_input);
                    ?>
                </div>
            </div>
            <div class = "col-md-2" id = "div_year" style = "padding:0% 2% 0% 1%">
                <?php
                    echo $ui->formField('dropdown')
                    ->setName('year')
                    ->setId('year')
                    ->setList(array('2018' => '2018', '2017' => '2017', '2016' => '2016', '2015' => '2015', '2014' => '2014', '2013' => '2013', '2012' => '2012', '2011' => '2011', '2010' => '2010'))
                    ->draw($show_input);
                ?>
            </div>
        </div>
        <div class = "row" style = "padding:2% 0% 0% 0%">
            <div class = "col-md-6 filter_col">
                <input type = "radio" name = "category" value = "by Airline" checked = "checked"> by Airline
                <div class = "col-md-12" style = "padding: 2% 0% 0% 5%">
                    <input type = "radio" name = "summary_route" value = "Summary"> Summary <br>
                    <input type = "radio" name = "summary_route" value = "Per Route"> Per Route 
                </div>
                <div class = "col-md-12" style = "padding: 5% 0% 0% 5%">
                    <input type = "radio" name = "a_rank_alpha" value = "Ranking"> Ranking <br>
                    <input type = "radio" name = "a_rank_alpha" value = "Alphabetical"> Alphabetical 
                </div>
                <div class = "col-md-12" style = "padding: 5% 0% 0% 5%">
                    <input type = "checkbox" name = "a_market_share" value = "Market Share"> Market Share
                </div>
            </div>
            <div class = "col-md-6 filter_col">
                <input type = "radio" name = "category" value = "by Country"> by Country
                <div class = "col-md-12" style = "padding: 2% 0% 0% 5%">
                    <input type = "radio" name = "c_rank_alpha" value = "Ranking"> Ranking <br>
                    <input type = "radio" name = "c_rank_alpha" value = "Alphabetical"> Alphabetical 
                </div>
            </div>
        </div>
    </div>
    <div class="panel panel-primary br-xs col-md-3" style = "margin: 2% 2% 2% 2%; padding: 3%">
        <div class = "row">
            <div id = "h_date_range">
                <div class = "col-md-2" style = "text-align:left; padding:0% 1% 0% 1%">
                    Fr:
                </div>
                <div class = "col-md-4" style = "padding:0% 1% 0% 0%">
                    <?php
                        echo $ui->formField('dropdown')
                        ->setName('start_year')
                        ->setId('start_year')
                        ->setList(array('2017' => '2017', '2016' => '2016', '2015' => '2015', '2014' => '2014', '2013' => '2013', '2012' => '2012', '2011' => '2011', '2010' => '2010', '2009' => '2009', '2008' => '2008', '2007' => '2007'))
                        ->draw($show_input);
                    ?>
                </div>
                <div class = "col-md-2" style = "text-align:left; padding:0% 0% 0% 1%">
                    To:
                </div>
                <div class = "col-md-4" style = "padding:0% 1% 0% 0%">
                    <?php
                        echo $ui->formField('dropdown')
                        ->setName('end_year')
                        ->setId('end_year')
                        ->setList(array('2018' => '2018', '2017' => '2017', '2016' => '2016', '2015' => '2015', '2014' => '2014', '2013' => '2013', '2012' => '2012', '2011' => '2011', '2010' => '2010', '2009' => '2009', '2008' => '2008'))
                        ->draw($show_input);
                    ?>
                </div>
            </div>
        </div>
        <div class = "row filter_col" style = "padding:2% 0% 0% 0%">
            <div class = "col-md-12">
                <input type = "radio" name = "category" value = "Historical"> Historical
                <div class = "col-md-12" style = "padding: 2% 0% 0% 5%">
                    <input type = "checkbox" name = "h_market_share" value = "Market Share"> Market Share
                </div>
            </div>
        </div>
    </div>
    </div>
    <div class = "row" style = "margin: 0% 0% 2% 2%">
        File Type: 
        <span style="margin-left:2px;">
            <button type = "button" style="font-size: 8pt; font-weight: bold;  border: 3px solid; padding: 5px; text-decoration: none; color: #444; background: #EEE" id = "pdf">PDF</button>
        </span>
        <span style="margin-left:2px;">
            <button type = "button" style="font-size: 8pt; font-weight: bold;  border: 3px solid; padding: 5px; text-decoration: none; color: #444; background: #EEE" id = "csv">CSV</button>
        </span>
    </div>
</div>
</form>
<script>
    $(document).ready(function(){
        $('#div_quarter').show();
        $('#div_year').show();
        $('#date_range').hide();
        $('#report_type').on('change', function() {
            var report_type = $('#report_type').val();
            if (report_type == 'Quarterly') {
                $('#div_quarter').show();
                $('#div_year').show();
                $('#date_range').hide();
            }
            else if (report_type == 'Consolidated') {
                $('#div_quarter').hide();
                $('#div_year').show();
                $('#date_range').show();
            }
            else {
                $('#div_quarter').hide();
                $('#div_year').show();
                $('#date_range').hide();
            }
        });
        $('#filters').on('ifToggled', 'input[name="fdgf"]', function () {
            $('#filters input[type="radio"], #filters input[type="checkbox"]').iCheck('disable').iCheck('uncheck');
            $('#filters input[name="fdgf"]').iCheck('enable');
            $(this).closest('.filter_col').find('input[type="radio"], input[type="checkbox"]').iCheck('enable');
        });
    });
</script>
<script>
    $("#pdf").on('click', function() {
        window.location = '<?php echo MODULE_URL ?>form_51b_pdf?' + $('#form51b').serialize();
    });
</script>