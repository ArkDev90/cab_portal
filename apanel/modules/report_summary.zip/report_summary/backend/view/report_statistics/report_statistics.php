<style>
	a {
		color:black;
	}
	a:hover {
		color:#22A;
		text-decoration:underline;
	}
</style>
<div class="panel panel-primary br-xs">
	<div class="panel-heading bb-colored text-center">
		LIST OF STATISTICS REPORTS
	</div>
	<div>
		<ul style = "list-style-type:none; padding: 2px">
			<li><a href="<?php echo MODULE_URL?>statistics_report51a"><b>Form 51-A</b> : Statistic Report</a><br>
			<li><a href="<?php echo MODULE_URL?>statistics_report51b"><b>Form 51-B</b> : Statistic Report</a><br>
			<li><a href="<?php echo MODULE_URL?>statistics_report61a"><b>Form 61-A</b> : Statistic Report</a><br>
			<li><a href="<?php echo MODULE_URL?>statistics_report61b"><b>Form 61-B</b> : Statistic Report</a><br>
			<li><a href="<?php echo MODULE_URL?>statistics_report71a"><b>Form 71-A</b> : Statistic Report</a><br>
			<li><a href="<?php echo MODULE_URL?>statistics_report71b"><b>Form 71-B</b> : Statistic Report</a><br>
			<li><a href="<?php echo MODULE_URL?>statistics_report71c"><b>Form 71-C</b> : Statistic Report</a><br>
			<li><a href="<?php echo MODULE_URL?>statistics_reportER2"><b>ER2 FORM2</b> : Statistic Report</a><br>
			<li><a href="<?php echo MODULE_URL?>statistics_reportT1a"><b>Form T1A</b> : Statistic Report</a><br>
		</ul>
	</div>
</div>