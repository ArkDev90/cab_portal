<?php
class report_summary_model extends wc_model {

	public function __construct() {
		parent::__construct();
		$this->log = new log();
	}

	public function get51BAC($report_type, $quarter, $year, $category, $a_rank_alpha, $c_rank_alpha, $start_date, $end_date) {
		$condition = '';
		if ($report_type == 'Quarterly') {
			if ($quarter == "1st Quarter") {
				$condition .= ' AND (report_month = "1" OR report_month = "2" OR report_month = "3")';
			}
			else if ($quarter == "2nd Quarter") {
				$condition .= ' AND (report_month = "4" OR report_month = "5" OR report_month = "6")';
			}
			else if ($quarter == "3rd Quarter") {
				$condition .= ' AND (report_month = "7" OR report_month = "8" OR report_month = "9")';
			}
			else {
				$condition .= ' AND (report_month = "10" OR report_month = "11" OR report_month = "12")';
			}
		}
		else if ($report_type == 'Consolidated') {
			if (($start_date == '1st Quarter') && ($end_date == '2nd Quarter')) {
				$condition .= ' AND (report_month >= "1" AND report_month <= "6")';
			}
			else if (($start_date == '1st Quarter') && ($end_date == '3rd Quarter')) {
				$condition .= ' AND (report_month >= "1" AND report_month <= "9")';
			}
			else if (($start_date == '1st Quarter') && ($end_date == '4th Quarter')) {
				$condition .= ' AND (report_month >= "1" AND report_month <= "12")';
			}
			else if (($start_date == '2nd Quarter') && ($end_date == '3rd Quarter')) {
				$condition .= ' AND (report_month >= "4" AND report_month <= "9")';
			}
			else if (($start_date == '2nd Quarter') && ($end_date == '4th Quarter')) {
				$condition .= ' AND (report_month >= "4" AND report_month <= "12")';
			}
			else if (($start_date == '3rd Quarter') &&($end_date == '4th Quarter')) {
				$condition .= ' AND (report_month >= "7" AND report_month <= "12")';
			}
			else {
				$condition .= ' AND (report_month >= "10" AND report_month <= "12")';
			}
		}
		else {
			$condition = '';
		}
		$sort = '';
		if ($category == 'by Airline') {
			if ($a_rank_alpha == 'Ranking') {
				$sort = 'total DESC';
			}
			else {
				$sort = 'fd.aircraft ASC';
			}
		}
		else if ($category == 'by Country') {
			if ($c_rank_alpha == 'Ranking') {
				$sort = 'total DESC';
			}
			else {
				$sort = 'od.title ASC';
			}
		}
		$result = $this->db->setTable('form51b f')
							->leftJoin('form51b_direct fd ON fd.form51b_id = f.id')
							->leftJoin('origin_destination od ON od.code = fd.routeFrom')
							->setFields('od.title, fd.aircraft, routeTo, routeFrom, cargoRev, cargoRevDep, (cargoRev + cargoRevDep) as total')
							->setWhere("status='Approved' AND year = '$year'".$condition)
							->setOrderBy($sort)
							->runPagination();
		return $result;
	}

	public function get51BH($start_year, $end_year) {
		$condition = "AND (year >= '$start_year' AND year <= '$end_year')";
		$result = $this->db->setTable('form51b f')
							->leftJoin('form51b_direct fd ON fd.form51b_id = f.id')
							->setFields('fd.aircraft, (sum(cargoRev) + sum(cargoRevDep)) as total')
							->setWhere("status='Approved'".$condition)
							->setGroupBy('fd.aircraft')
							->runPagination();
		return $result;
	}

	public function getAirlines() {
		$result = $this->db->setTable('client')
							->setFields("id ind, name val")
							->setOrderBy('name')
							->runSelect()
							->getResult();
		return $result;
	}

	public function get61BSummary($report_type, $quarter, $year, $start_date, $end_date, $rank_alpha, $passenger_cargo) {
		$condition = '';
		if ($report_type == 'Quarterly') {
			if ($quarter == "1st Quarter") {
				$condition .= ' AND (f.report_month = "1" OR f.report_month = "2" OR f.report_month = "3")';
			}
			else if ($quarter == "2nd Quarter") {
				$condition .= ' AND (f.report_month = "4" OR f.report_month = "5" OR f.report_month = "6")';
			}
			else if ($quarter == "3rd Quarter") {
				$condition .= ' AND (f.report_month = "7" OR f.report_month = "8" OR f.report_month = "9")';
			}
			else {
				$condition .= ' AND (f.report_month = "10" OR f.report_month = "11" OR f.report_month = "12")';
			}
		}
		else if ($report_type == 'Consolidated') {
			if (($start_date == '1st Quarter') && ($end_date == '2nd Quarter')) {
				$condition .= ' AND (f.report_month >= "1" AND f.report_month <= "6")';
			}
			else if (($start_date == '1st Quarter') && ($end_date == '3rd Quarter')) {
				$condition .= ' AND (f.report_month >= "1" AND f.report_month <= "9")';
			}
			else if (($start_date == '1st Quarter') && ($end_date == '4th Quarter')) {
				$condition .= ' AND (f.report_month >= "1" AND f.report_month <= "12")';
			}
			else if (($start_date == '2nd Quarter') && ($end_date == '3rd Quarter')) {
				$condition .= ' AND (f.report_month >= "4" AND f.report_month <= "9")';
			}
			else if (($start_date == '2nd Quarter') && ($end_date == '4th Quarter')) {
				$condition .= ' AND (f.report_month >= "4" AND f.report_month <= "12")';
			}
			else if (($start_date == '3rd Quarter') &&($end_date == '4th Quarter')) {
				$condition .= ' AND (f.report_month >= "7" AND f.report_month <= "12")';
			}
			else {
				$condition .= ' AND (f.report_month >= "10" AND f.report_month <= "12")';
			}
		}
		else {
			$condition = '';
		}
		$sort = '';
		if ($rank_alpha == 'Ranking') {
			if ($passenger_cargo == 'Passenger') {
				$sort = 'passengers_num DESC';
			}
			else {
				$sort = 'cargo_qty DESC';
			}
		}
		else {
			$sort = 'name ASC';
		}
		$result = $this->db->setTable('form61b f')
							->leftJoin('form61b_details fd ON fd.form61b_id = f.id')
							->leftJoin('client c ON c.id = f.client_id')
							->setFields('name, sum(cargo_qty) as cargo_qty, sum(passengers_num) as passengers_num, origin, destination,
										sum(distance) as distance, sum(flown_hour) as hours, sum(flown_min) as minutes, sum(revenue) as revenue')
							->setWhere("f.status='Approved' AND f.year = '$year'".$condition)
							->setOrderBy($sort)
							->setGroupBy('name')
							->runPagination();
		return $result;
	}

	public function get61bSummaryPerOperator($report_type, $quarter, $year, $start_date, $end_date, $airline) {
		$condition = '';
		if ($report_type == 'Quarterly') {
			if ($quarter == "1st Quarter") {
				$condition .= ' AND (f.report_month = "1" OR f.report_month = "2" OR f.report_month = "3")';
			}
			else if ($quarter == "2nd Quarter") {
				$condition .= ' AND (f.report_month = "4" OR f.report_month = "5" OR f.report_month = "6")';
			}
			else if ($quarter == "3rd Quarter") {
				$condition .= ' AND (f.report_month = "7" OR f.report_month = "8" OR f.report_month = "9")';
			}
			else {
				$condition .= ' AND (f.report_month = "10" OR f.report_month = "11" OR f.report_month = "12")';
			}
		}
		else if ($report_type == 'Consolidated') {
			if (($start_date == '1st Quarter') && ($end_date == '2nd Quarter')) {
				$condition .= ' AND (f.report_month >= "1" AND f.report_month <= "6")';
			}
			else if (($start_date == '1st Quarter') && ($end_date == '3rd Quarter')) {
				$condition .= ' AND (f.report_month >= "1" AND f.report_month <= "9")';
			}
			else if (($start_date == '1st Quarter') && ($end_date == '4th Quarter')) {
				$condition .= ' AND (f.report_month >= "1" AND f.report_month <= "12")';
			}
			else if (($start_date == '2nd Quarter') && ($end_date == '3rd Quarter')) {
				$condition .= ' AND (f.report_month >= "4" AND f.report_month <= "9")';
			}
			else if (($start_date == '2nd Quarter') && ($end_date == '4th Quarter')) {
				$condition .= ' AND (f.report_month >= "4" AND f.report_month <= "12")';
			}
			else if (($start_date == '3rd Quarter') &&($end_date == '4th Quarter')) {
				$condition .= ' AND (f.report_month >= "7" AND f.report_month <= "12")';
			}
			else {
				$condition .= ' AND (f.report_month >= "10" AND f.report_month <= "12")';
			}
		}
		else {
			$condition = '';
		}
		
		$result = $this->db->setTable('form61b f')
							->leftJoin('form61b_details fd ON fd.form61b_id = f.id')
							->leftJoin('client c ON c.id = f.client_id')
							->leftJoin('aircraft_type a ON a.id = fd.aircraft')
							->setFields('name, a.title, aircraft_num, cargo_qty, passengers_num, origin, destination,
										distance, flown_hour, flown_min, revenue')
							->setWhere("f.status='Approved' AND f.year = '$year' AND f.client_id = '$airline'".$condition)
							->runPagination();
		return $result;
	}

}